# SPDX-License-Identifier: MIT
# SPDX-FileCopyrightText: © 2026 HSE AG, <opensource@hseag.com>

import json
import urllib.error
import urllib.parse
import urllib.request

from .lookup_table import LookupTable
from .measurement import Results
from .verification import Verification


class RestApiError(RuntimeError):
    """Raised when a REST request fails or returns a non-success status."""


class RestClient:
    """HTTP client for the eviFluor REST API."""

    def __init__(self, base_url="http://127.0.0.1:8000", serial_number=None):
        """Initializes a REST client.

        Args:
            base_url: Base URL of the REST service.
            serial_number: Optional default device identifier used for device
                scoped routes.
        """
        self.base_url = base_url.rstrip("/")
        self.serial_number = serial_number

    def _device_path(self, suffix):
        """Builds a device-scoped API path.

        Args:
            suffix: Route suffix below the device endpoint.

        Returns:
            Fully qualified device endpoint URL.
        """
        if self.serial_number:
            device_id = urllib.parse.quote(self.serial_number)
            return f"{self.base_url}/api/v1/devices/{device_id}/{suffix}"
        return f"{self.base_url}/api/v1/device/{suffix}"

    def _run_path(self, run_id, suffix=""):
        """Builds a run-scoped API path.

        Args:
            run_id: Encoded run identifier returned by the REST API.
            suffix: Optional route suffix below the run endpoint.

        Returns:
            Fully qualified run endpoint URL.
        """
        encoded = urllib.parse.quote(run_id)
        if suffix:
            return f"{self.base_url}/api/v1/runs/{encoded}/{suffix}"
        return f"{self.base_url}/api/v1/runs/{encoded}"

    def _request_json(self, method, url, payload=None):
        """Performs an HTTP request and decodes the JSON response.

        Args:
            method: HTTP method such as ``"GET"`` or ``"POST"``.
            url: Fully qualified request URL.
            payload: Optional JSON-serializable request body.

        Returns:
            Parsed JSON response payload.
        """
        data = None
        headers = {}

        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"

        request = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(request) as response:
                return json.load(response)
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RestApiError(f"HTTP {exc.code} for {url}\n{body}") from exc
        except urllib.error.URLError as exc:
            raise RestApiError(f"Request failed for {url}: {exc}") from exc

    def _request_text(self, method, url, payload=None):
        """Performs an HTTP request and returns the response body as text.

        Args:
            method: HTTP method such as ``"GET"`` or ``"POST"``.
            url: Fully qualified request URL.
            payload: Optional JSON-serializable request body.

        Returns:
            Response body decoded as UTF-8 text.
        """
        data = None
        headers = {}

        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"

        request = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(request) as response:
                return response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RestApiError(f"HTTP {exc.code} for {url}\n{body}") from exc
        except urllib.error.URLError as exc:
            raise RestApiError(f"Request failed for {url}: {exc}") from exc

    def health(self):
        return self._request_json("GET", f"{self.base_url}/api/v1/health")

    def version(self):
        return self._request_json("GET", f"{self.base_url}/api/v1/version")

    def list_devices(self):
        return self._request_json("GET", f"{self.base_url}/api/v1/devices")

    def info(self):
        return self._request_json("GET", self._device_path("info"))

    def selftest(self):
        return self._request_json("POST", self._device_path("selftest"))

    def checkempty(self):
        return self._request_json("GET", self._device_path("checkempty"))

    def status(self):
        """Return the service-side device status (`idle`, `busy`, or `error`)."""
        return self._request_json("GET", self._device_path("status"))

    def run_init(self, nr_of_std_low, nr_of_std_high, concentration, no_air=False, kit="Default", settling_time=None, k1=None, k2=None, k3=None, lookup_table=None):
        """Initializes a new run through the REST API.

        Args:
            nr_of_std_low: Number of low-standard replicates.
            nr_of_std_high: Number of high-standard replicates.
            concentration: Concentration assigned to the high standard.
            no_air: If ``True``, the run uses the sample-only workflow.
            kit: Kit name or alias understood by the backend.
            settling_time: Optional settling-time override in seconds.
            k1: Optional kit parameter override.
            k2: Optional kit parameter override.
            k3: Optional kit parameter override.
            lookup_table: Optional lookup-table list or CSV/JSON filename.

        Returns:
            JSON response describing the initialized run.
        """
        payload = {
            "nr_of_std_low": nr_of_std_low,
            "nr_of_std_high": nr_of_std_high,
            "concentration": concentration,
            "no_air": no_air,
            "kit": kit,
            "settling_time": settling_time,
        }
        if k1 is not None:
            payload["k1"] = k1
        if k2 is not None:
            payload["k2"] = k2
        if k3 is not None:
            payload["k3"] = k3
        if lookup_table is not None:
            if isinstance(lookup_table, str):
                payload["lookup_table"] = LookupTable.load(lookup_table).to_json()
            else:
                payload["lookup_table"] = lookup_table
        if self.serial_number:
            payload["device_id"] = self.serial_number
        return self._request_json("POST", f"{self.base_url}/api/v1/runs", payload)

    def run_get(self, run_id):
        """Fetches the current state of a run.

        Args:
            run_id: Encoded run identifier.

        Returns:
            JSON response describing the run state.
        """
        return self._request_json("GET", self._run_path(run_id))

    def run_measure(self, run_id, comment=None):
        """Executes the next measurement step for a run.

        Args:
            run_id: Encoded run identifier.
            comment: Optional comment stored with the next completed measurement.

        Returns:
            Tuple ``(verification, result)`` matching :meth:`Run.measure`.
            ``verification`` is returned as :class:`Verification`.
            ``result`` is returned as :class:`Results` or ``None``.
        """
        payload = self._request_json("POST", self._run_path(run_id, "measure"), {"comment": comment})
        result = payload["result"]
        return Verification.from_json(payload["verification"]), None if result is None else Results.from_json(result)

    def run_results(self, run_id):
        """Fetches all currently available calculated run results.

        Args:
            run_id: Encoded run identifier.

        Returns:
            List of :class:`Results` in measurement order.
        """
        payload = self._request_json("GET", self._run_path(run_id, "results"))
        return [Results.from_json(result) for result in payload]

    def run_verifications(self, run_id):
        """Fetches all currently stored run verifications.

        Args:
            run_id: Encoded run identifier.

        Returns:
            List of :class:`Verification` in measurement order.
        """
        payload = self._request_json("GET", self._run_path(run_id, "verifications"))
        return [Verification.from_json(verification) for verification in payload]

    def run_export_csv(self, run_id):
        """Exports a run to CSV and returns the response body.

        Args:
            run_id: Encoded run identifier.

        Returns:
            CSV response body as text.
        """
        return self._request_text("POST", self._run_path(run_id, "export/csv"), {})

    def run_data(self, run_id):
        """Fetches the persisted measurement JSON for a run.

        Args:
            run_id: Encoded run identifier.

        Returns:
            JSON response containing the run data file content.
        """
        return self._request_json("GET", self._run_path(run_id, "data"))
